import LogoShowcase from "@/components/brand/logo-showcase"

export default function BrandPage() {
  return <LogoShowcase />
}
